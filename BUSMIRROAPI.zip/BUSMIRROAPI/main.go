package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"

	"github.com/gorilla/mux"
)

type user struct {
	ID           string `json:"ID"`
	First_Name   string `json:"First_Name"`
	Last_Name    string `json:"Last_Name"`
	Email        string `json:"Email"`
	Phone_Number string `json:"Phone_Number"`
}

type alluser []user

var users = alluser{
	{
		ID:           "1",
		First_Name:   "HARSH",
		Last_Name:    "CHAURASIA",
		Email:        "iamharshchaurasia@gmail.com",
		Phone_Number: "8224804713",
	},
}

func homeLink(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "USER PORTAL!")
}

func createuser(w http.ResponseWriter, r *http.Request) {
	var newuser user
	reqBody, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Fprintf(w, "Kindly enter data of the user")
	}

	json.Unmarshal(reqBody, &newuser)
	users = append(users, newuser)
	w.WriteHeader(http.StatusCreated)

	json.NewEncoder(w).Encode(newuser)
}

func getuser(w http.ResponseWriter, r *http.Request) {
	userID := mux.Vars(r)["id"]

	for _, singleuser := range users {
		if singleuser.ID == userID {
			json.NewEncoder(w).Encode(singleuser)
		}
	}
}

func getAllusers(w http.ResponseWriter, r *http.Request) {
	json.NewEncoder(w).Encode(users)
}

func edituser(w http.ResponseWriter, r *http.Request) {
	userID := mux.Vars(r)["id"]
	var updateduser user

	reqBody, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Fprintf(w, "Kindly enter data with ID , FIRST NAME , LAST NAME , EMAIL , PHONE NUMBER only in order to update")
	}
	json.Unmarshal(reqBody, &updateduser)

	for i, singleuser := range users {
		if singleuser.ID == userID {
			singleuser.First_Name = updateduser.First_Name
			singleuser.Last_Name = updateduser.Last_Name
			users = append(users[:i], singleuser)
			json.NewEncoder(w).Encode(singleuser)
		}
	}
}

func main() {
	initusers()
	router := mux.NewRouter().StrictSlash(true)
	router.HandleFunc("/", homeLink)
	router.HandleFunc("/user", createuser()).Methods("POST")
	router.HandleFunc("/users", getAllusers).Methods("GET")
	router.HandleFunc("/users/{id}", getOneuser).Methods("GET")
	router.HandleFunc("/users/{id}", updateuser).Methods("PATCH")
	log.Fatal(http.ListenAndServe(":8080", router))
}


